﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WholeasaleBase.Classes;


namespace WholeasaleBase.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPage.xaml
    /// </summary>
   
    public partial class AddEditPage : Page
    //новое поле, которое будет хранить в себе экземпляры добавляемого пользователя
    {
        private Product _currentProduct = new Product();

        public AddEditPage(Product selectedProduct) // в конструктор добавлен параметр типа Person
        { //создаём контекст  
            InitializeComponent();
            if (selectedProduct != null)
                _currentProduct = selectedProduct;
            //создаем контекст
            DataContext = _currentProduct;
            CmbProv.ItemsSource = WholesaleDBEntities.GetContext().Provider.ToList();
            CmbProv.SelectedValuePath = "IdProv";
            CmbProv.DisplayMemberPath = "Name";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentProduct.Name))
                error.AppendLine("Укажите название");
            //if (string.IsNullOrWhiteSpace(_currentProduct.Note))
            //    error.AppendLine("Укажите описание товара");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentProduct.IdProd == 0)
                WholesaleDBEntities.GetContext().Product.Add(_currentProduct); //добавить в контекст
            try
            {
                WholesaleDBEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый продукт добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
