﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WholeasaleBase.Classes;

namespace WholeasaleBase.Pages
{
    /// <summary>
    /// Логика взаимодействия для Images.xaml
    /// </summary>
    public partial class Images : Page
    {
        public Images()
        {
            InitializeComponent();
            var currentProduct = WholesaleDBEntities.GetContext().Product.ToList();
            LViewProducts.ItemsSource = currentProduct;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPage((sender as Button).DataContext as Product));
        }
    }
}
